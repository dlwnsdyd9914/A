//
//  AuthCoordinator.swift
//  A
//
//  Created by 이준용 on 4/10/25.
//

import UIKit

final class AuthCoordinator: AuthRouting {

    private weak var nav: UINavigationController?

    init(navigationController: UINavigationController) {
        self.nav = navigationController
    }


    func start() {
        navigate(to: .login)
    }

    func navigate(to destination: AuthDestination) {
        switch destination {
        case .login:
            let loginVC = LoginViewController(router: self)
            nav?.setViewControllers([loginVC], animated: false)

        case .register:
            let vc = RegisterViewController(router: self)
            nav?.pushViewController(vc, animated: true)
        }
    }
    func popNav() {
        nav?.popViewController(animated: true)
    }



}
