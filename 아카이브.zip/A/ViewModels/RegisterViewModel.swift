//
//  RegisterViewModel.swift
//  A
//
//  Created by 이준용 on 4/10/25.
//

import UIKit

class RegisterViewModel {

    private(set) var profileImage: UIImage? {
        didSet {
            onProfileImage?(profileImage)
            isSelected = (profileImage?.size != .zero)
            validateForm()
        }
    }

    private var email: String? {
        didSet {
            validateForm()
        }
    }

    private var password: String? {
        didSet {
            validateForm()
        }
    }

    private var username: String? {
        didSet {
            validateForm()
        }
    }

    private var fullname: String? {
        didSet {
            validateForm()
        }
    }

    private var isSelected = false
    private var validate = false

    var onProfileImage: ((UIImage?) -> Void)?
    var onValidationChange: ((Bool, UIColor) -> Void)?


    func bindProfileImage(profileImage: UIImage) {
        self.profileImage = profileImage
    }

    func bindTextField(_ textField: UITextField) {

        guard let customField = textField as? CustomTextField,
              let type = customField.fieldType,
              let text = customField.text else { return }

        switch type {
        case .email:
            self.email = text
        case .password:
            self.password = text
        case .fullname:
            self.fullname = text
        case .username:
            self.username = text
        }
    }

    func validateForm() {
        validate = [
            email?.isEmpty == false,
            password?.isEmpty == false,
            username?.isEmpty == false,
            fullname?.isEmpty == false,
            isSelected
        ].allSatisfy({$0})
        onValidationChange?(validate, validate ? UIColor.buttonEnabled : .buttonDisabled)
    }


}
