//
//  UIImage+Icons.swift
//  A
//
//  Created by 이준용 on 4/10/25.
//

import UIKit

extension UIImage {

    // MARK: - TabBar Icons
    static let feedImage = UIImage(named: "home_unselected")!
    static let searchImage = UIImage(named: "search_unselected")!
    static let notificationImage = UIImage(named: "like_unselected")!

    // MARK: - Auth / Form
    static let emailImage = UIImage(named: "mail")!
    static let passwordImage = UIImage(named: "ic_lock_outline_white_2x")!
    static let nameFieldImage = UIImage(named: "ic_person_outline_white_2x")!

    // MARK: - Common
    static let mainLogo = UIImage(named: "TwitterLogo")!
    static let newTweetImage = UIImage(named: "new_tweet")!
    static let addProfileImage = UIImage(named: "plus_photo")!

    // MARK: - Tweet Actions
    static let commentImage = UIImage(named: "add-library")!
    static let retweetImage = UIImage(named: "add-library")!
    static let shareImage = UIImage(named: "share")!
    static let likeImage = UIImage(named: "like")!
    static let backImage = UIImage(named: "baseline_arrow_back_white_24dp")!
}
